package openmrs.prism.utils;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.model.Author;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.codoid.products.exception.FilloException; 
import com.google.common.io.Files;

import openmrs.core.common.utils.Reporter;
import openmrs.core.driver.Driver;
import openmrs.core.driver.DriverFactory;
import openmrs.core.testng.listeners.DriverListener;

public class SeleniumUtils extends Reporter{
	public static final String EXCELCOLUMNKEY = "excelColumnId";
	public static final String EXCELROWKEY = "excelRowId";
	public static String UserDirVar = System.getProperty("user.dir"); // Current Location
	public static ExtentReports extendReports;
	public static ExtentTest testCase;
	public static ExtentTest parentTest;
	public static ExtentTest childTest;
	public static WebDriver webDriver;
	public static Properties SeleniumProps;
	public static String outputFilePath = null;
	public static String outputHtmlPath = null;
	public static String toastMessageElement = "//*[@id='toast-container']//div[@class='toast-message']";
	public static String toastMessageCloseElement = "//*[@class='toast-close-button']";
	public static Boolean enabledSuccesscreenshot = true;
	public static Boolean enabledFailureScreenshot = true;
	public static JavascriptExecutor js = null;
	public static Properties commonProps;
	public static WebDriverWait wait = null;
	public DriverFactory driverFactory;
	public static boolean isproduction = true;
	public static String environmentName ;
	public static double version ;
	public static boolean isExcelDataWritter = false; 
	/**
	 * Return the properties of given file
	 * @param ConfigFilePath
	 * @return
	 * @throws IOException
	 * @author ilayaraja
	 */
	public static Properties getConfigProprty(String ConfigFilePath) throws IOException{
		try {
			Properties prop=new Properties();
			FileInputStream ip= new FileInputStream(UserDirVar+ConfigFilePath);
			prop.load(ip);
			return prop;
		} catch (Exception e) {
			return null;
		}
	}
 


	public void startApp(String url) {
		try {
			WebDriver driver = Driver.getWebDriver();
			driver.navigate().to(url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);

		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("The Browser Could not be Launched. Hence Failed");
			Reporter.reportStep("fail", e.getMessage());
			throw new RuntimeException();
		}

	}

	public static void sendKeys(By element, String data, boolean snap) {
		WebElement ele = null; 
		try {
			WebDriver driver = Driver.getWebDriver();
			ele = findElement(element);
			ele.sendKeys(data);
			Reporter.reportStep("pass", "Data entered Successfully - "+data,snap);
		} catch (ElementNotInteractableException e) {
			Reporter.reportStep("fail", "Element is not Interactable - "+data);
		}catch (Exception e) {
			Reporter.reportStep("fail", "Element is not Interactable - "+data+ e.getMessage());
		}
	}

	public static void sendKeys(By element, String data) {
		sendKeys(element,data,false);
	}
	public static WebElement findElement(By by) {
		WebDriver driver = Driver.getWebDriver();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(by));
		return driver.findElement(by);
	}
	public static void waitForElementvisibilityOf(By ele) {
		WebDriver driver = Driver.getWebDriver();
		WebElement element = findElement(ele);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public static String getTextfromField(By byElement,String fieldName){
		String FiledVal = "";
		try {
			WebDriver webDriver = Driver.getWebDriver();		 
			FiledVal = webDriver.findElement(byElement).getText();	
			Reporter.reportStep("pass", "Get text from field "+fieldName);
		} catch (Exception e) {
			Reporter.reportStep("fail", "Not able to Get text from field "+fieldName);
			FiledVal = "";
			e.printStackTrace();
		}
		return FiledVal;
	}
	
	public static void click(By ele, String text, boolean snap) {
		WebDriver driver = Driver.getWebDriver();
		try {
			driver.findElement(ele).click();
			if (!waitForPageLoad()) {
				Reporter.reportStep("fail","When click " + text + " clicked page will load more then 30 sec",snap);
			} else {
				System.out.println("##loading working correctly");
			}
			Reporter.reportStep("pass","The Element " + text + " is clicked",snap);
		} catch (StaleElementReferenceException e) {
			try {

				WebElement element = waitForElementRefresh(ele);
				element.click();		

			}catch (Exception ex) {
				Reporter.reportStep("fail", "The Element " + text + " could not be clicked as it is stale in js click");

				System.out.println("Expe : " + ex);
				throw new RuntimeException(); 
			}
		}  catch (Exception e) {
			Reporter.reportStep("fail", "The Element " + text + " could not be clicked as it is have Exception");
			throw new RuntimeException(); 
		}

	}

	public static void click(By ele, String text) {
		click(ele,text,false);
	}

	
	public void uploadExcelFile(String excelLocation) {

		StringSelection selection = new StringSelection(excelLocation);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);

		try {
			Thread.sleep(3000);
			Robot robot = new Robot();	
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static WebElement waitForElementRefresh(By elemSelector) {
		try {
			WebDriver driver = Driver.getWebDriver();
			wait = new WebDriverWait(driver, 10);
			//return wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(elemSelector)));
			return wait.until(ExpectedConditions.refreshed(new ExpectedCondition<WebElement>() {
				@Override
				public WebElement apply(WebDriver driver) {
					waitUntilElementDisplayed(elemSelector);
					return driver.findElement(elemSelector);
				}
			}));
		} catch (Exception e) {
			return null;
		}
	}
	 
	public boolean isDispaly(By element) {
		WebDriver driver = Driver.getWebDriver();
		try {
			 driver.findElement(element).isDisplayed();
			 return true;
		}catch (Exception e) {
			return false;
		}
		
		
	}
	
	public void selectByVisibleText(By by, String keysToSend) {
		WebElement ele = findElement(by);
		try {
			Select select= new Select(ele);
			select.selectByVisibleText(keysToSend);
			Reporter.reportStep("pass", keysToSend+" is selected successfully");
		} catch (Exception E) {
			Reporter.reportStep("fail", keysToSend+" is not selected successfully");
			//				throw new RuntimeException();
		}
	}
	public static void threadSleep(int sec) {

		try {
			Thread.sleep(sec);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public static boolean waitForElementHideWithTime(By elemSelector,int sec) {
		try {
			WebDriver driver = Driver.getWebDriver();
			wait = new WebDriverWait(driver, sec);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(elemSelector));
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	public static boolean waitUntilElementDisplayed(By elemSelector) {
		try {
			WebDriver driver = Driver.getWebDriver();
			wait = new WebDriverWait(driver, 7); 
			wait.until(ExpectedConditions.visibilityOfElementLocated(elemSelector));
			return true;
		}catch (Exception e) {
			return false;
		}
	}
	/**
	 * Wait for complete loading in UI
	 * @return
	 */
	public static boolean waitForPageLoad() {
		WebDriver driver = Driver.getWebDriver();
		ExpectedCondition<Boolean> expect = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		wait = new WebDriverWait(driver, 30);
		try {
			wait.until(expect);
		} catch (Exception E) {
			return false;
		}
		return true;
	}
}