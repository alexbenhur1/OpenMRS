package openmrs.prism.rerun;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryFailedTestCases implements IRetryAnalyzer{
	 int retryMinCount=0;
	int retryMaxCount = 2;
	@Override
	public boolean retry(ITestResult result) {
		if (retryMinCount<retryMaxCount) {
			retryMinCount++;
			return true;
		}
		return false;
	}

}
