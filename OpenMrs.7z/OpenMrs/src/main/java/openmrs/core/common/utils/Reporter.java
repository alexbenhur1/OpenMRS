package openmrs.core.common.utils;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.codoid.products.exception.FilloException; 
import com.google.common.io.Files;

import openmrs.core.driver.Driver;
import openmrs.core.testng.listeners.DriverListener;

public abstract class Reporter {
	
	public static ThreadLocal<String> htmlFile;
	public static ThreadLocal<ExtentHtmlReporter> reporter = new ThreadLocal<ExtentHtmlReporter>();
	public static ThreadLocal<ExtentReports> extent = new ThreadLocal<ExtentReports>();
	public static ThreadLocal<ExtentTest> eTestScenario = new ThreadLocal<ExtentTest>();
	public static ThreadLocal<ExtentTest> eTestCase= new ThreadLocal<ExtentTest>();
	public static int pass=0;
	public static int fail=0;
	public static int info=0;
	public static int skip=0;
	public static WebDriver driver;
	
	/**
	 * Create Report generation object and attaching the Report
	 * @throws FilloException 
	 */
	public void startReport(String htmlFileName) throws FilloException {
		reporter.set(new ExtentHtmlReporter(DriverListener.reportFolder + "/" + htmlFileName + ".html"));
		extent.set(new ExtentReports());
		extent.get().attachReporter(reporter.get());
	}
	
	/**
	 * flush the Report
	 */
	public static void flushReport(){
		try {
			extent.get().flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void createNode(String testCase) {
		eTestCase.set(eTestScenario.get().createNode(testCase));
	}
	
	public static String takeSnap(){
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
		try {
			Files.copy(((TakesScreenshot) Driver.getWebDriver()).getScreenshotAs(OutputType.FILE) , new File("./reports/images/"+number+".jpg"));
		} catch (WebDriverException e) {
			System.out.println("The browser has been closed.");
		} catch (IOException e) {
			System.out.println("The snapshot could not be taken");
		}
		return "./reports/images/"+number+".jpg";
	}
	
	public static String getBase64(){
		return ((TakesScreenshot) Driver.getWebDriver()).getScreenshotAs(OutputType.BASE64);
	}

	public static void reportStep(String status, String desc,boolean bSnap ) {
    	if(status.equalsIgnoreCase("pass")) {
    		++pass;
    		eTestCase.get().pass(desc);
    		if(true) eTestCase.get().addScreenCaptureFromBase64String(getBase64());
    	} else if(status.equalsIgnoreCase("fail")) {
    		++fail;
    		eTestCase.get().fail(desc); 
    		eTestCase.get().addScreenCaptureFromBase64String(getBase64());
    	} else if(status.equalsIgnoreCase("INFO")) {
    		++info;
    		eTestCase.get().info(desc); 
    	}else if(status.equalsIgnoreCase("SKIP")) {
    		++skip;
    		eTestCase.get().skip(desc); 
    	}
    }
    public static void reportStep( String status,String desc) {
		reportStep(status,desc, false);
	}


}
