
package openmrs.core.testng.listeners;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

import openmrs.prism.utils.SeleniumUtils;
 

public class RetryAnalyzer implements IRetryAnalyzer {
	public static Properties seleniumConfigProp  = null;

	static{
		try {
			seleniumConfigProp = SeleniumUtils.getConfigProprty("\\ModuleConfigurations\\seleniumconfig.properties");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
    private static AtomicInteger count;
    private static final int maxTry = Integer.parseInt(seleniumConfigProp.getProperty("RetryCount")) ;

    public RetryAnalyzer() {
        count = new AtomicInteger(0);
    }

    @Override
    public boolean retry(ITestResult iTestResult) {
        if (!iTestResult.isSuccess()) {
            if (count.get() < maxTry) {
                count.incrementAndGet(); 
                iTestResult.setStatus(ITestResult.FAILURE);
                return true;
            } else {
                iTestResult.setStatus(ITestResult.FAILURE);
            }
        } else {
            iTestResult.setStatus(ITestResult.SUCCESS);
        }
        return false;
    }

    public static int getCount() {
        return count.get();
    }

}


