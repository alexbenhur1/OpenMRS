package openmrs.core.testng.listeners;

import java.io.File;
import java.io.IOException;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import openmrs.core.common.utils.GenericUtils;
import openmrs.core.common.utils.Reporter;
import openmrs.prism.utils.SeleniumUtils; 

@SuppressWarnings("deprecation")
public class DriverListener
		implements ISuiteListener, ITestListener, IInvokedMethodListener/* , IAnnotationTransformer */ {
	public static String reportFolder;
	public static String screenshotFolder;
	public static String downloadsFolder;
	public static File downloadFolder;
	public static File reportsFolder;
	public String includedGroups;
	public String excludedGroups;
	public static boolean isCucumber = false;
	public static ThreadLocal<String> testScenarioID = new ThreadLocal<>();
	public static ThreadLocal<String> testSheetName = new ThreadLocal<>();
	public static ThreadLocal<String> mainWorkbook = new ThreadLocal<>();

	public static Properties MYLISTPROP  = null;
	public static Properties ACTIVITYPROP  = null;
	public static Properties TABSELECTIONPROP  = null;
	public static Properties ACCCREATIONPROP = null;
	
	@Override
	public void onStart(ISuite suite) {
		reportFolder = "./reports/test-output-" + GenericUtils.getTimeStamp();
		reportsFolder = new File(reportFolder);
		downloadsFolder = reportFolder + "/downloads";
		downloadFolder = new File(downloadsFolder);
		reportsFolder.mkdirs();
		downloadFolder.mkdirs();

		try {
			SeleniumUtils.SeleniumProps = SeleniumUtils.getConfigProprty("\\src\\test\\java\\resources\\openMrs.properties");
			 
			//setIsProductionMode(); /OpenMrs/src/test/java/resources/openMrs.properties
		     //setEnvironmentName();
			//MYLISTPROP = SeleniumUtils.getConfigProprty("\\ModuleConfigurations\\mylist.properties");
			//ACTIVITYPROP = SeleniumUtils.getConfigProprty("\\ModuleConfigurations\\activity.properties");
			//TABSELECTIONPROP = SeleniumUtils.getConfigProprty("\\ModuleConfigurations\\tabSelection.properties");
			//ACCCREATIONPROP = SeleniumUtils.getConfigProprty("\\ModuleConfigurations\\accountcreation.properties");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
 

	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult result) {

	}

	@Override
	public void onFinish(ISuite suite) {
		
	}

	private void takeFailureScreenshot() {
//		if (!Driver.isWebDriverEmpty()) {
//			WebActions actions = new WebActions();
//			actions.logScreenshot("Failure Screenshot");
//		}
	}

	@Override
	public void onTestStart(ITestResult result) {

//		Reporter.eTestScenario.set(Reporter.extent.createTest(testScenario.get(), testDescription.get()));
		/*
		 * IRetryAnalyzer curRetryAnalyzer = getRetryAnalyzer(result); if
		 * (curRetryAnalyzer == null) {
		 * result.getMethod().setRetryAnalyzer(curRetryAnalyzer); }
		 */
	}

	@Override
	public void onTestSuccess(ITestResult result) {

		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailure(ITestResult result) {
		try { 
			String exceptionCause = result.getThrowable().getCause().toString();
			StringBuilder exceptionDetails = new StringBuilder();
			int causeExceptionLength = result.getThrowable().getCause().getStackTrace().length;
	//		if(causeExceptionLength>4) {
	//			causeExceptionLength=4;
	//		}
			for(int i=0 ; i<causeExceptionLength ; i++) {
				String className = result.getThrowable().getCause().getStackTrace()[i].getClassName();
				String methodName = result.getThrowable().getCause().getStackTrace()[i].getMethodName();
				int lineNumber = result.getThrowable().getCause().getStackTrace()[i].getLineNumber();
				exceptionDetails.append("<b>'Exception Reason'</b>  : "+exceptionCause+"  <b>  'Class Name'</b> : <span style='color:#FD1C03;'> "+
			    className +"</span> <b>  'Method Name' </b>:<span style='color:#A52A2A;'> "+methodName+"<b> </span> 'Line Number' :<span style='color:#800000;'> "+lineNumber +" </span>  </b> <br>");
				
			}
			 
			if(exceptionCause.contains("101")) {
				Reporter.reportStep("info", exceptionCause);
			}else {
				Reporter.reportStep("fail", exceptionDetails.toString() );
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void onTestSkipped(ITestResult result) {

		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

		// TODO Auto-generated method stub

	}

	@Override
	public void onStart(ITestContext context) {

		// TODO Auto-generated method stub

	}

	@Override
	public void onFinish(ITestContext ctx) {
		// TODO Auto-generated method stub

	}

	public String convert(long miliSeconds) {
		int hrs = (int) TimeUnit.MILLISECONDS.toHours(miliSeconds) % 24;
		int min = (int) TimeUnit.MILLISECONDS.toMinutes(miliSeconds) % 60;
		int sec = (int) TimeUnit.MILLISECONDS.toSeconds(miliSeconds) % 60;
		return String.format("%02d:%02d:%02d", hrs, min, sec);
	}


	/*
	 * private RetryAnalyzer getRetryAnalyzer(ITestResult result) { RetryAnalyzer
	 * retryAnalyzer = null; IRetryAnalyzer iRetry =
	 * result.getMethod().getRetryAnalyzer(); if (iRetry instanceof RetryAnalyzer) {
	 * retryAnalyzer = (RetryAnalyzer) iRetry; } return retryAnalyzer; }
	 * 
	 * @Override public void transform(ITestAnnotation annotation, Class testClass,
	 * Constructor testConstructor, Method testMethod) { IRetryAnalyzer analyzer =
	 * annotation.getRetryAnalyzer(); if (analyzer == null) {
	 * annotation.setRetryAnalyzer(RetryAnalyzer.class); } }
	 */

	enum TestStatus {
		PASS(1), FAIL(2), SKIP(3);
		private int statusCode;

		private TestStatus(int code) {
			this.statusCode = code;
		}

		public int getCode() {
			return this.statusCode;
		}
	}

}
