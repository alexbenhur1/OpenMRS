package openmrs.function;

import static org.testng.Assert.assertEquals;

import javax.security.auth.login.LoginContext;

import openmrs.bo.PaitentDetailsBo;
import openmrs.core.common.utils.Reporter;
import openmrs.pages.CaptureVitalPage;
import openmrs.pages.DashboardPage;
import openmrs.pages.LoginPage;
import openmrs.pages.MergeVisitPage;
import openmrs.pages.PaitentLoginPage;
import openmrs.pages.PaitentRecordPage;
import openmrs.pages.RegsisterPaitentPage;
import openmrs.pages.StartVisitPage;

public class TestSteps  {

	LoginPage login = new LoginPage();
	DashboardPage dashboard = new DashboardPage();
	RegsisterPaitentPage regPatient = new RegsisterPaitentPage();
	PaitentLoginPage paitentLogin = new PaitentLoginPage();
	StartVisitPage startVisit = new StartVisitPage();
	CaptureVitalPage captureVital = new CaptureVitalPage();
	MergeVisitPage mergeVisit = new MergeVisitPage(); 
	PaitentRecordPage recordPage = new PaitentRecordPage();
	
	public String getCurrentUrl() {
		return login.getUrl();
	}

	public void enterLoginDetails() {
		login.enterUserName("Admin");
		login.enterPassWord("Admin123");
		login.selectLocation();
		login.clickLoginBtn();
	}

	public boolean verifyDashboardPageLunch() {
		return dashboard.verifyHomePage();
	}

	public void regsisterPatient(PaitentDetailsBo paitentDetails) {
		 dashboard.clickRegsisterPatient();
		 regPatient.verifyRegisterFormDisplayed();
		 regPatient.enterpatientName(paitentDetails.getPaitentName());
		 regPatient.enterpatienFamilytName(paitentDetails.getPaitenFamilyName());
		 regPatient.clickNextBtn();
		 regPatient.selectGender(paitentDetails.getGender());
		 regPatient.clickNextBtn();
		 regPatient.enterDOB(paitentDetails.getDOB());
		 regPatient.clickNextBtn();
		 regPatient.enterAddress(paitentDetails.getAddress());
		 regPatient.clickNextBtn();
		 regPatient.enterPhoneNo(paitentDetails.getPhoneNo());
		 regPatient.clickNextBtn();
		 regPatient.clickNextBtn();
		 
	}

	public boolean verifyFillFormDetails(PaitentDetailsBo paitentDetails) {
		boolean status =true;
		String paitentName =  regPatient.getPaitentName();
		String gender =  regPatient.getGender();
		String Address =  regPatient.getAddress();
		String phoneNo =  regPatient.getPhoneNo();
		String dob =  regPatient.getDOB();
		System.out.println(paitentName);
		if(paitentName.contains(paitentDetails.getPaitentName()) && paitentName.contains(paitentDetails.getPaitenFamilyName())) {
			Reporter.reportStep("pass", "paitent name dispalyed correctly");
		}else {
			Reporter.reportStep("fail", "paitent name not dispalyed correctly");
			status =false;
		}
		
		if(phoneNo.contains(paitentDetails.getPhoneNo())) {
			Reporter.reportStep("pass", "Phone Number dispalyed correctly");
		}else {
			Reporter.reportStep("fail", "Phone Number not dispalyed correctly");
			status =false;
		}
		
		
		if(gender.contains(paitentDetails.getGender())) {
			Reporter.reportStep("pass", "gender dispalyed correctly");
		}else {
			Reporter.reportStep("fail", "gender not dispalyed correctly");
			status =false;
		}
		
		if(Address.contains(paitentDetails.getAddress())) {
			Reporter.reportStep("pass", "Address dispalyed correctly");
		}else {
			Reporter.reportStep("fail", "Address not dispalyed correctly");
			status =false;
		}
		
		String[] DateOfBirith = paitentDetails.getDOB().split("/"); 
		//DOB Day
		if(dob.contains(DateOfBirith[0])) {
			Reporter.reportStep("pass", "DOB day dispalyed correctly");
		}else {
			Reporter.reportStep("fail", "DOB day not dispalyed correctly");
			status =false;
		}
		//DOB month
		if(dob.contains(DateOfBirith[1])) {
			Reporter.reportStep("pass", "DOB month dispalyed correctly");
		}else {
			Reporter.reportStep("fail", "DOB month not dispalyed correctly");
			status =false;
		}
		//DOB year
		if(dob.contains(DateOfBirith[2])) {
			Reporter.reportStep("pass", "DOB year dispalyed correctly");
		}else {
			Reporter.reportStep("fail", "DOB year not dispalyed correctly");
			status =false;
		}
		
		return status;
	}

	public void clickConfirmAndVerifyCalCulatedAge(PaitentDetailsBo paitentDetails) {
		 regPatient.clickConfirm();
		 if(paitentLogin.verifyDateisDisplayed()) {
			 paitentLogin.calCulateAge(paitentDetails.getDOB());
		 }
		 
		 
		
	}

	public void startVisit() {
		paitentLogin.clickStartVisit();
		paitentLogin.clickConfirm();
		startVisit.clickAttachment();
		startVisit.uploadDocument();
		startVisit.enterCaption("Alex Report test");
		startVisit.clickUpload();
		startVisit.getToastMsg();
		startVisit.redirectToPaitentDetails();
		if(paitentLogin.verifyPaitentPageisDisplayed()) {
			Reporter.reportStep("pass", "Paitent details page redirect successfully");
		}else {
			Reporter.reportStep("fail", "Paitent details page not redirect successfully");
		}
			
	}

	public void verifyAttachementFile() {
		paitentLogin.clickAttachmentEdit();
		startVisit.attachmentIsDispaly("");
		startVisit.redirectToPaitentDetails();
		paitentLogin.verifyPaitentPageisDisplayed();
	}

	public void verifyRecentVisitDate() {
		 paitentLogin.verfyRecentDate();
		
	}

	public void endVisit() {
		paitentLogin.endVisit();
		paitentLogin.endVisitConfirm();
		
		
	}

	public void startVistAgain() {
		paitentLogin.clickStartVisit();
		paitentLogin.clickConfirm();
		startVisit.redirectToPaitentDetails();
		paitentLogin.verifyPaitentPageisDisplayed();
		
	}

	public void captureVitals() {
		 paitentLogin.clickCaptureVitals();
		 captureVital.verifyCaptureScreen();
		 captureVital.enterHight();
		 captureVital.clickNextBtn();
		 captureVital.enterWeight();
		 captureVital.clickNextBtn();
		 captureVital.verifyBMICalculation();
		 captureVital.clickNextBtn();
		 captureVital.clickNextBtn();
		 captureVital.clickNextBtn();
		 captureVital.clickNextBtn();
		 captureVital.clickNextBtn();
		 captureVital.clickNextBtn(); 
		 captureVital.clickSaveBtn();
		 paitentLogin.verifyPaitentPageisDisplayed();
	}

	public void verifyBMiValues() {
		 paitentLogin.verifyHeight();
		 paitentLogin.verifyHeight();
		 paitentLogin.verifyBMI();
		
	}

	public void verifyVitalTag() {
		 paitentLogin.verfyRecentDateWithVirtalTag();
		
	}

	public void mergeVisit() {
		 paitentLogin.clickMergeVisit();
		 mergeVisit.selectVisit();
		 mergeVisit.clickMerge();
	     startVisit.redirectToPaitentDetails();
		 paitentLogin.verifyPaitentPageisDisplayed();
	}

	public void verifyMergeRecentVisit() {
		 paitentLogin.verifymergeRecentvisit();
		
	}

	public void verifyAddPastDate() {
		 
		paitentLogin.clickAddPastVisit();
		paitentLogin.verifyFutureDateIsDisable();
		paitentLogin.clickAddPastCancel();
	}

	public void deletePaitent() {
		String paitentId = paitentLogin.getPaitentId();
		 paitentLogin.deletePaient();
		 paitentLogin.deleteReason("Paitent miss detail not matched");
		 paitentLogin.clickDeleteConfirm();
		 paitentLogin.getToastMsg();
		 recordPage.verifyDeletedPaitentId(paitentId);
		 
		 
		 
	}

	
	
	
}
