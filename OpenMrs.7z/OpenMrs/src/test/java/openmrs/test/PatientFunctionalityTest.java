package openmrs.test;
 
import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;
 

import openmrs.annotation.Annotations;
import openmrs.bo.PaitentDetailsBo;
import openmrs.function.TestSteps;
import openmrs.pages.MergeVisitPage;

public class PatientFunctionalityTest extends Annotations {

	TestSteps steps = new TestSteps();
	PaitentDetailsBo paitentDetails = new PaitentDetailsBo();
	
	
	
	@Test
	public void gotoUrl() {
		 createNode("Verify URL loaded or not");
		 String currentUrl =steps.getCurrentUrl();
		 assertEquals(SeleniumProps.get("url"), currentUrl);
		 reportStep("pass", "login url load sucessfully");
	}
	
	@Test(dependsOnMethods = {"gotoUrl"})
	public void login() {
		 createNode("Enter Username(Admin) and password(Admin123");
		 steps.enterLoginDetails();
		 createNode("Verify dashboard page is redirected using Assertion.");
		 boolean status=  steps.verifyDashboardPageLunch();
		 assertEquals(status, true);
	}
	@Test(dependsOnMethods = {"login"})
	public void regsisterPatient() {
		 createNode("Enter the detail of Demographics(Name, Gender, Birthdate) and Contact Info(Address, Phone number)");
		 paitentDetails.setPaitentName("Alex");
		 paitentDetails.setPaitenFamilyName("Ben Hur");
		 paitentDetails.setGender("Male");
		 paitentDetails.setAddress("Sivakasi");
		 paitentDetails.setPhoneNo("114256");
		 paitentDetails.setDOB("14/February/1995");
		 steps.regsisterPatient(paitentDetails);
		 createNode("Then at Confirm page, verify the given Name, Gender, Birthdate, Address, Phone number are populated correctly using Assertion.");
		 boolean status = steps.verifyFillFormDetails(paitentDetails);
		 assertEquals(status, true);
		 createNode("Click on Confirm and verify Patient details page is redirected and verify the age is calculated correctly based on the date of birth provided.  ");
		 steps.clickConfirmAndVerifyCalCulatedAge(paitentDetails);
	}
	@Test(dependsOnMethods = {"regsisterPatient"})
	public void startVist() {
		createNode(" Click on Start Visit and Confirm the visit.");
		steps.startVisit();
		
	}
	@Test(dependsOnMethods = {"startVist"})
	public void verifyAttachement() {
		
		createNode("Click on Attachment and complete the upload process.");
		steps.verifyAttachementFile();
		createNode("Verfiy Recent Visit has one entry for current date with Attachment Upload tag");
		steps.verifyRecentVisitDate();
	}
	@Test(dependsOnMethods = {"verifyAttachement"})
	public void endVisit() {
		createNode("Click on the End Visit action at RHS.");
		steps.endVisit();
		createNode(" Start Visit again and Click on Capture Vitals menu.");
		steps.startVistAgain();
		steps.captureVitals();
		createNode("Click on End Visit and redirect to Patient details page.");
		steps.endVisit();
	}
	
	@Test(dependsOnMethods = {"endVisit"})
	public void VerifyBmiInPaitentDetails() {
		createNode("In Patient details screen, verify the given Height and Weight is displayed correctly along with calculated BMI.");
		steps.verifyBMiValues();
		createNode("Verfiy Recent Visit has one more new entry for current date with Vitals tag.");
		steps.verifyVitalTag();
	}
	
	@Test(dependsOnMethods = {"VerifyBmiInPaitentDetails"})
	public void mergeVist() {
		createNode("Click on Merge Visits, select these 2 visit and click on Merge Selected Visits button.");
		steps.mergeVisit();
		createNode("Verfiy Recent Visit has become one entry for current date with Vitals,Attachment Upload tag.");
		steps.verifyMergeRecentVisit();
		createNode("Click on Add Past Visit and verify the future date is not clickable in the date picker. ");
		steps.verifyAddPastDate();
		createNode("It will redirect you to Find Patient Record menu where verify the deleted patient should not listed out in the table using search options. ");
		steps.deletePaitent();
	}
	
	
	
}
