package openmrs.annotation;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

import com.codoid.products.exception.FilloException;

import openmrs.core.driver.Driver;
import openmrs.core.driver.DriverFactory;
import openmrs.core.testng.listeners.DriverListener;
import openmrs.prism.utils.SeleniumUtils; 

public class Annotations extends SeleniumUtils{
	
	@BeforeClass(alwaysRun = true)
	public void beforeClass(ITestContext ctx) throws FilloException {
		DriverFactory.driverSetup("chrome");
		startApp(SeleniumProps.getProperty("url"));
		driver = Driver.getWebDriver();
		Driver.getWebDriver().get(SeleniumProps.getProperty("url"));
		startReport("Report");
	    eTestScenario.set(extent.get().createTest(this.getClass().getSimpleName(),"validate the "));
		 
		
	}

	@AfterClass(alwaysRun = true)
	public void afterClass(ITestContext ctx) {
 
	}
	
	/**
	 * This method use to clear java heap memory space
	 * Reload the URL
	 */
	@AfterMethod
	public void afterMethod() {
			
	 
	}
	
	@AfterSuite
	public void afterSuit() {
		 flushReport();
		 String backslash = "\\";
		 String doc = System.getProperty("user.dir");
		 doc+= backslash +backslash+DriverListener.reportsFolder+backslash+"Report.html"; 
		  startApp(doc);
		   
	}
	
}
