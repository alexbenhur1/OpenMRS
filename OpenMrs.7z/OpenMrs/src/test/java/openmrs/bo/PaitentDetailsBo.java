package openmrs.bo;

public class PaitentDetailsBo {
	private String paitentName ="";
	private String paitenFamilyName="";
	private String gender ="";
	private String DOB ="";
	private String address ="";
	private String phoneNo="";
	
	
	public String getPaitenFamilyName() {
		return paitenFamilyName;
	}
	public void setPaitenFamilyName(String paitenFamilyName) {
		this.paitenFamilyName = paitenFamilyName;
	}
	public String getPaitentName() {
		return paitentName;
	}
	public void setPaitentName(String paitentName) {
		this.paitentName = paitentName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
}
