package openmrs.pages;

import org.openqa.selenium.By;

import openmrs.prism.utils.SeleniumUtils;

public class StartVisitPage extends SeleniumUtils {
	String attachedID ="attachments.attachments.visitActions.default";
	String uploadAttachment ="visit-documents-dropzone";
	String captionField ="//textarea";
	String uploadBtn ="//button[contains(text(),'Upload')]";
	String toastMsg ="//div[contains(@class,'toast-container')]//p";
	String reDirPaitentPage ="//ul[@id='breadcrumbs']//li[2]//a";
	
	
	
	public void clickAttachment()  {
		 click(By.id(attachedID), "Attached");
	}
	public void uploadDocument() {
		 click(By.id(uploadAttachment), "Attached files");
		 String backslash = "\\";
		 String doc = System.getProperty("user.dir");
		 doc+= backslash + "tec.txt"; 
		 uploadExcelFile(doc); 
		 
		
	}
	public void enterCaption(String caption) {
	   sendKeys(By.xpath(captionField), caption);
		
	}
	public void clickUpload() {
		 click(By.xpath(uploadBtn), "upload btn");
	}
	public void getToastMsg() {
		 waitForElementvisibilityOf(By.xpath(toastMsg));
		 String msg = getTextfromField(By.xpath(toastMsg), "toast msg");
	     System.out.println(msg);
	     if(msg.equalsIgnoreCase("The attachment was successfully uploaded.")) {
	    	 reportStep("pass", "Uploaded toast msg displayed sucessfully");
	     }else {
	    	 reportStep("fail", "Uploaded toast msg not displayed sucessfully");
	     }
	}
	public void redirectToPaitentDetails() {
		waitForElementvisibilityOf(By.xpath(reDirPaitentPage));
		click(By.xpath(reDirPaitentPage), "Redirect to paitent deatils");
		
	}
	public void attachmentIsDispaly(String attachmentName) {
		 String attXpath ="//div[contains(@class,'att_thumbnails')]//*[contains(text(),'"+attachmentName+"')]";
		 waitForElementvisibilityOf(By.xpath(attXpath));
		 if(isDispaly(By.xpath(attXpath))) {
			 reportStep("pass", "Attached documrnt is displayed");
		 }else {
			 reportStep("fail", "Attached documrnt is not displayed");
		 }
		
	}
	 
}
