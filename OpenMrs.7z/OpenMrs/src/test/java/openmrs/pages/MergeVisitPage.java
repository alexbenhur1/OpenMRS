package openmrs.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import openmrs.prism.utils.SeleniumUtils;

public class MergeVisitPage extends SeleniumUtils{
    String visitListCheckbox ="//table[@id='active-visits']//input";
	public void selectVisit() {
		 List<WebElement> listOfVist = driver.findElements(By.xpath(visitListCheckbox));
		 for(WebElement checkBox : listOfVist) {
			 checkBox.click();
		 }
		
	}
	public void clickMerge() {
		click(By.id("mergeVisitsBtn"), "merge");
	}

}
