package openmrs.pages;

import org.openqa.selenium.By;

import openmrs.prism.utils.SeleniumUtils;

public class DashboardPage extends SeleniumUtils {
	String dashBoardApps ="apps";
	String regsisterPatientLink = "referenceapplication-registrationapp-registerPatient-homepageLink-referenceapplication-registrationapp-registerPatient-homepageLink-extension";
	public boolean verifyHomePage() {
		 waitForElementvisibilityOf(By.id(dashBoardApps));
		 return isDispaly(By.id(dashBoardApps));
	}
	public void clickRegsisterPatient() {
		 click(By.id(regsisterPatientLink), "Register Patient link");	
	}
		
}
