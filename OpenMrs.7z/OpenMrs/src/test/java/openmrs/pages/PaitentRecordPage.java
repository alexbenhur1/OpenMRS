package openmrs.pages;

import org.openqa.selenium.By;

import openmrs.prism.utils.SeleniumUtils;

public class PaitentRecordPage extends SeleniumUtils {

	public void verifyDeletedPaitentId(String paitentId) {
		 sendKeys(By.id("patient-search"),paitentId);
		 threadSleep(4);
		 if(isDispaly(By.xpath("//table[@id='patient-search-results-table']//td[contains(text(),'No matching records found')]"))) {
			 reportStep("pass", "Deleted paitent detail not in record");
		 }else {
			 reportStep("fail", "Deleted paitent detail in record");
		 }
		
	}

}
