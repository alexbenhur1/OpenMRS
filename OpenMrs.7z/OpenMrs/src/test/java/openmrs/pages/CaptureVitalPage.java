package openmrs.pages;

import org.openqa.selenium.By;

import openmrs.core.common.utils.Reporter;
import openmrs.prism.utils.SeleniumUtils;

public class CaptureVitalPage extends SeleniumUtils {
    String vitalForm ="formBreadcrumb";
    String hightField ="//span[@id='height']//input";
    String weightField ="//span[@id='weight']//input";
    String nextBtn="next-button";
    String BMIvalue ="calculated-bmi";
    String saveBtn ="//button[@type='submit']";
	
    
    public void verifyCaptureScreen() {
    	waitForElementvisibilityOf(By.id(vitalForm));
    	if(isDispaly(By.id(vitalForm))) {
    		reportStep("pass", "Vital screen is dispalyed");
    	}else {
    		reportStep("fail", "Vital screen is not dispalyed");
    		throw new RuntimeException("vital screen not loaded");
    	}
	}


	public void enterHight() {
		sendKeys(By.xpath(hightField), "165");
	}


	public void clickNextBtn() {
		click(By.id(nextBtn), "Next button");
	}


	public void enterWeight() {
		sendKeys(By.xpath(weightField), "65");
	}


	public void verifyBMICalculation() {
		String bmi = getTextfromField(By.id(BMIvalue), "BMI value");
		System.out.println(bmi);
		double uiBmiValue = Double.parseDouble(bmi) ;
		double height =165*0.01;
		double weight =65;
		double caluculateBmi =weight/(height*height);
		System.out.println(caluculateBmi);
		if(Math.round(uiBmiValue)== Math.round(caluculateBmi)) {
			reportStep("pass", "Calculated bmi value is correct");
		}else {
			reportStep("fail", "Calculated bmi value is incorrect Expcepted :"+uiBmiValue +" Actual : "+caluculateBmi );
		}
	    
	
	}


	public void clickSaveBtn() {
		click(By.xpath(saveBtn), "save button");
	}

	
	
}
