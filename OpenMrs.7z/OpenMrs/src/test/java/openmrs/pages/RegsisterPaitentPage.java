package openmrs.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.SendKeysAction;

import openmrs.prism.utils.SeleniumUtils;

public class RegsisterPaitentPage extends SeleniumUtils {
	String regsisterFormId = "registration";
	String paitentNameInput= "//input[@name='givenName']";
	String PaitentFamilNameInput = "//input[@name='familyName']"; 
	String nextBtn ="next-button";
	String genderId = "gender-field";
	String dayField = "birthdateDay-field";
	String monthField ="birthdateMonth-field";
	String yearField= "birthdateYear-field";
	String addressId = "address1";
	String phoneXpath ="//input[@name='phoneNumber']";
	String getName = "//div[@id='dataCanvas']//span[contains(text(),'Name:')]//parent::p";
	String getGenderValue= "//div[@id='dataCanvas']//span[contains(text(),'Gender:')]//parent::p";
	String getAddress = "//div[@id='dataCanvas']//span[contains(text(),'Address: ')]//parent::p";
	String getPhoneNo = "//div[@id='dataCanvas']//span[contains(text(),'Phone Number: ')]//parent::p";
	String getDOB ="//div[@id='dataCanvas']//span[contains(text(),'Birthdate: ')]//parent::p";
	
	public void verifyRegisterFormDisplayed() {
	     waitForElementvisibilityOf(By.id(regsisterFormId));
	     if(isDispaly(By.id(regsisterFormId))) {
	    	 reportStep("pass", "Patient Regsister form is Displayed");
	     }else {
	    	 reportStep("fail", "Patient Regsister form is not Displayed");
	    	 throw new RuntimeException("paitent form not dispalyed");
	     }
	}

	public void enterpatientName(String paitentName) {
		sendKeys(By.xpath(paitentNameInput), paitentName);
	}
	public void enterpatienFamilytName(String paitenFamilytName) {
		sendKeys(By.xpath(PaitentFamilNameInput), paitenFamilytName);
	}

	public void clickNextBtn() {
		 click(By.id(nextBtn), "Next button");
	}

	public void selectGender(String gender) {
		 selectByVisibleText(By.id(genderId), gender);
		
	}

	public void enterDOB(String dob) {
		 String[] dateOfBirth = dob.split("/");
		 sendKeys(By.id(dayField), dateOfBirth[0]);
		 selectByVisibleText(By.id(monthField), dateOfBirth[1]);
		 sendKeys(By.id(yearField), dateOfBirth[2]);
		
	}

	public void enterAddress(String address) {
		sendKeys(By.id(addressId), address);
	}

	public void enterPhoneNo(String phoneNo) {
		 sendKeys(By.xpath(phoneXpath), phoneNo);
		
	}

	public String getPaitentName() {
		return getTextfromField(By.xpath(getName), "paitent name");
	}
	
	public String getGender() {
		return getTextfromField(By.xpath(getGenderValue), "Gender ");
	}
	public String getAddress() {
		return getTextfromField(By.xpath(getAddress), "Address ");
	}
	public String getPhoneNo() {
		return getTextfromField(By.xpath(getPhoneNo), "phone No ");
	}
	public String getDOB() {
		return getTextfromField(By.xpath(getDOB), "DOB ");
	}

	public void clickConfirm() {
		 click(By.id("submit"), "Confirm");
		
	}
	
	
}
