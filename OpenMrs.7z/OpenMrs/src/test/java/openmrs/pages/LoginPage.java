package openmrs.pages;

import org.openqa.selenium.By;

import openmrs.core.common.utils.Reporter;
import openmrs.prism.utils.SeleniumUtils;

public class LoginPage extends SeleniumUtils {
	String userNameInput = "username";
	String passInput  = "password";
	String locationselect ="//ul[@id='sessionLocation']//li";
	String loginBtn ="loginButton";
	public String getUrl() {
		return driver.getCurrentUrl();
	}

	public void enterUserName(String userName) {
			sendKeys(By.id(userNameInput), userName);
	}
	public void enterPassWord(String pass) {
		sendKeys(By.id(passInput), pass);
	}

	public void selectLocation() {
		 click(By.xpath(locationselect), "Select any loction");
	}

	public void clickLoginBtn() {
		click(By.id(loginBtn), "Login Button");
		
	}

	
	
	
}
