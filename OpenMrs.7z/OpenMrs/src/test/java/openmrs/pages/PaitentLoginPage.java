package openmrs.pages;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import openmrs.prism.utils.SeleniumUtils;

public class PaitentLoginPage extends SeleniumUtils {
	
	String PaitentAgeXpath = "//div[contains(@class,'gender-age')]//span[2]"; 
	String startVist ="//div[contains(text(),'Start Visit')]";
	String addPastVisit ="//div[contains(text(),'Add Past Visit')]";
	String PaitenDelete ="//div[contains(text(),'Delete Patient')]";
	String mergeVisit ="//div[contains(text(),'Merge Visits')]";
	String captureVital ="(//div[contains(text(),'Capture Vitals')])[2]";
	String startVistConfirm ="start-visit-with-visittype-confirm";
	String paitentHomePage ="//div[contains(@class,'dashboard ')]";
	String attachmentEditXpath ="//div[contains(@class,'dashboard ')]//*[contains(text(),'ATTACHMENTS')]//parent::div//i[@title='Edit']";
	String endVisitXpath="(//a[@id='referenceapplication.realTime.endVisit']//*[contains(text(),'End Visit')])[2]";
	String endVisitConfirm="//div[@id='end-visit-dialog']//button[contains(@class,'confirm right')]";
	String getHeight ="//span[@id='height']//span";
	String getWeight ="//span[@id='weight']//span";
	String calculatrdBmi="calculated-bmi";
	String futureDate ="//table//td[contains(@class,'disabled')]";
	String paitentDeleteConfirm ="//div[@id='delete-patient-creation-dialog']//button[@class='confirm right']";
	String toastMsg ="//div[contains(@class,'toast-container')]//p";
	
	public boolean verifyDateisDisplayed() {
		 waitForElementvisibilityOf(By.xpath(PaitentAgeXpath));
		 return isDispaly(By.xpath(PaitentAgeXpath));
	}

	public void calCulateAge(String dob) {
		 LocalDate curDate = LocalDate.now();
		 String[] dateOfBirth = dob.split("/");
		 LocalDate brithday = LocalDate.parse(dateOfBirth[2]+"-"+"02"+"-"+dateOfBirth[0]);  
		 int calcuatedAge =  Period.between(brithday, curDate).getYears();
	     String UiAge = getTextfromField(By.xpath(PaitentAgeXpath), "DOB");
	     String[] paitentUiAge = UiAge.split("year");
	     int age = Integer.parseInt(paitentUiAge[0].trim());
	     if(age==calcuatedAge) {
	    	 reportStep("pass", "Calculated age is display correctly");
	     }else {
	    	 reportStep("fail", "Calculated age is not display correctly");
	     }
	
	}

	public void clickStartVisit() {
		 click(By.xpath(startVist),"start visit");
		 
	}
	
	public void clickConfirm() {
		click(By.id(startVistConfirm), "confirm");
	}

	public boolean verifyPaitentPageisDisplayed() {
		waitForElementvisibilityOf(By.xpath(paitentHomePage));
		return isDispaly(By.xpath(paitentHomePage));
		
	}

	public void clickAttachmentEdit() {
		click(By.xpath(attachmentEditXpath), "Edit Attachement");
		
	}

	public void verfyRecentDate() {
		  String date= "";
		  SimpleDateFormat simpleformat = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss");
		  simpleformat = new SimpleDateFormat("dd/MMMM/yyyy");
		  simpleformat = new SimpleDateFormat("MMMM");
	      String strMonth= simpleformat.format(new Date());
	      simpleformat = new SimpleDateFormat("dd/MMMM/yyyy");
	      String currentDate = simpleformat.format(new Date());
	      String[] curDate = currentDate.split("/");
	      date =curDate[0]+"."+strMonth.trim().substring(0, 3)+"."+curDate[2];
	      System.out.println(date);
	      String currentDatexpath ="//*[contains(text(),'RECENT VISITS')]//parent::*//parent::*//a[contains(text(),'"+date+"')]";
	      waitForElementvisibilityOf(By.xpath(currentDatexpath));
	      if(isDispaly(By.xpath(currentDatexpath))) {
	    	  reportStep("pass", "Current date is displayed in recent visit");
	      }else {
	    	  reportStep("fail", "Current date is not displayed in recent visit");
	      }
	      String attachmentTagXpath ="//*[contains(text(),'RECENT VISITS')]//parent::*//parent::*//a[contains(text(),'"+date+"')]//following-sibling::div[contains(text(),'Attachment')]";
	      if(isDispaly(By.xpath(attachmentTagXpath))) {
	    	  reportStep("pass", "Current date with attachment tag is displayed in recent visit");
	      }else {
	    	  reportStep("fail", "Current date with attachment tag is not displayed in recent visit");
	      }
	       
		
	}

	public void endVisit() {
		click(By.xpath(endVisitXpath), "end visit");
		
	}

	public void endVisitConfirm() {
		click(By.xpath(endVisitConfirm), "end visit confirm yes");
		waitForElementHideWithTime(By.xpath(endVisitConfirm), 5);
	}

	public void clickCaptureVitals() {
		 click(By.xpath(captureVital),"Capture vitals");
	}

	public void verifyHeight() {
		 String height = getTextfromField(By.xpath(getHeight), " height");
		 if(height.trim().equalsIgnoreCase("165")) {
			 reportStep("pass", "Given height is display correctly");
		 }else {
			 reportStep("fail", "Given height is not display correctly");
		 }
		
	}
	
	public void verifyWeight() {
		 String height = getTextfromField(By.xpath(getWeight), " weight");
		 if(height.trim().equalsIgnoreCase("68")) {
			 reportStep("pass", "Given weight is display correctly");
		 }else {
			 reportStep("fail", "Given weight is not display correctly");
		 }
		
	}
	
	public void verifyBMI() {
		 String BMI = getTextfromField(By.id(calculatrdBmi), " BMI");
		 if(BMI.trim().equalsIgnoreCase("23.9")) {
			 reportStep("pass", "Given BMI is display correctly");
		 }else {
			 reportStep("fail", "Given BMI is not display correctly Expected :23.9  Actual :"+BMI );
		 }
		
	}
	
	public void verfyRecentDateWithVirtalTag() {
		  String date= "";
		  SimpleDateFormat simpleformat = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss");
		  simpleformat = new SimpleDateFormat("dd/MMMM/yyyy");
		  simpleformat = new SimpleDateFormat("MMMM");
	      String strMonth= simpleformat.format(new Date());
	      simpleformat = new SimpleDateFormat("dd/MMMM/yyyy");
	      String currentDate = simpleformat.format(new Date());
	      String[] curDate = currentDate.split("/");
	      date =curDate[0]+"."+strMonth.trim().substring(0, 3)+"."+curDate[2];
	      System.out.println(date);
	      String currentDatexpath ="//*[contains(text(),'RECENT VISITS')]//parent::*//parent::*//a[contains(text(),'"+date+"')]";
	      waitForElementvisibilityOf(By.xpath(currentDatexpath));
	      if(isDispaly(By.xpath(currentDatexpath))) {
	    	  reportStep("pass", "Current date is displayed in recent visit");
	      }else {
	    	  reportStep("fail", "Current date is not displayed in recent visit");
	      }
	      String attachmentTagXpath ="//*[contains(text(),'RECENT VISITS')]//parent::*//parent::*//a[contains(text(),'"+date+"')]//following-sibling::div[contains(text(),'Vitals')]";
	      if(isDispaly(By.xpath(attachmentTagXpath))) {
	    	  reportStep("pass", "Current date with Vitals tag is displayed in recent visit");
	      }else {
	    	  reportStep("fail", "Current date with Vitals tag is not displayed in recent visit");
	      }
	       
		
	}

	public void clickMergeVisit() {
		click(By.xpath(mergeVisit), "merge visit");
		
	}

	public void verifymergeRecentvisit() {
		 String date= "";
		  SimpleDateFormat simpleformat = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss");
		  simpleformat = new SimpleDateFormat("dd/MMMM/yyyy");
		  simpleformat = new SimpleDateFormat("MMMM");
	      String strMonth= simpleformat.format(new Date());
	      simpleformat = new SimpleDateFormat("dd/MMMM/yyyy");
	      String currentDate = simpleformat.format(new Date());
	      String[] curDate = currentDate.split("/");
	      date =curDate[0]+"."+strMonth.trim().substring(0, 3)+"."+curDate[2];
	      System.out.println(date);
	      String currentDatexpath ="//*[contains(text(),'RECENT VISITS')]//parent::*//parent::*//a[contains(text(),'"+date+"')]";
	      List<WebElement> list = driver.findElements(By.xpath(currentDatexpath));
	      if(list.size()==1) {
	    	  reportStep("pass", "Merged vist is displayed in recent vist as per expected");
	      }else {
	    	  reportStep("fail", "Merged vist is not displayed in recent vist as per expected");
	      }
		
	}

	public void clickAddPastVisit() {
		click(By.xpath(addPastVisit), "add past visit");
	}

	public void verifyFutureDateIsDisable() {
	     if(isDispaly(By.xpath("//table//td[contains(@class,'disabled')]"))) {
	    	 reportStep("pass", "Future date is disable");
	     }else {
	    	 reportStep("fail", "Future date is not disable");
	     }
		
	}

	public void deletePaient() {
		click(By.xpath(PaitenDelete), "delete paitent");
		
	}

	public void deleteReason(String reason) {
		sendKeys(By.id("delete-reason"), reason);
	}

	public void clickDeleteConfirm() {
		click(By.xpath(paitentDeleteConfirm), "delete confirm");
		
	}

	public String getPaitentId() {
		return getTextfromField(By.xpath("//div[contains(@class,'identifiers ')]//span"), "paitent id");
	}

	public void getToastMsg() {
		 waitForElementvisibilityOf(By.xpath(toastMsg));
		 String msg = getTextfromField(By.xpath(toastMsg), "toast msg");
	     System.out.println(msg);
	     if(msg.equalsIgnoreCase("Patient has been deleted successfully")) {
	    	 reportStep("pass", "Delete paitent toast msg displayed sucessfully");
	     }else {
	    	 reportStep("fail", "Delete paitent  toast msg not displayed sucessfully");
	     }
	}

	public void clickAddPastCancel() {
		click(By.xpath("//div[@id='simplemodal-container']//button[@class='cancel']"), "cancel ");
		
	}
	
}
